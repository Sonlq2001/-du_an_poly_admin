export const sorting = (data) => {
  const result = data;
  console.log(data);
  return null;
};
