import styled from 'styled-components';

export const GroupAlert = styled.div`
  .alert-main {
    font-size: 1.3rem;
  }
`;
