import React, {memo} from 'react'

const Page404Screen = () => {
  return (
    <div>
      page 404
    </div>
  )
}

export default memo(Page404Screen)
