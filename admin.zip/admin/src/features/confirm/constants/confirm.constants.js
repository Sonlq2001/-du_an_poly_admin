export const DATA_FAKE = [
	{
		id: 1,
		name: "website bán hàng",
		class: "pt1514",
		subject: "Đồ án tốt nghiêp",
		semester: 7,
		member: ["Lê Quang Sơn, Nguyễn Hữu Sơn"],
	},
	{
		id: 2,
		name: "Thiết kế nội thất gia đình",
		class: "pt1514",
		subject: "Đồ án tốt nghiêp",
		semester: 7,
		member: ["Lê Quang Sơn, Nguyễn Hữu Sơn"],
	},
	{
		id: 3,
		name: "Ứng dụng đặt đồ ăn",
		class: "pt1514",
		subject: "Đồ án tốt nghiêp",
		semester: 7,
		member: ["Lê Quang Sơn, Nguyễn Hữu Sơn"],
	},
	{
		id: 4,
		name: "Thiết kế ô tô",
		class: "pt1514",
		subject: "Đồ án tốt nghiêp",
		semester: 7,
		member: ["Lê Quang Sơn, Nguyễn Hữu Sơn"],
	},
];
