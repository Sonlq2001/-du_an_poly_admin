export const UPLOAD_EXCEL_PATH = {
  UPLOAD: '/upload-excel',
};
