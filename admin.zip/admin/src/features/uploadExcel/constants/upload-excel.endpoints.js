export const UPLOAD_EXCEL_ENDPOINTS = {
  UPLOAD_EXCEL: '/import',
  GET_SEMESTERS: '/semesters',
};
