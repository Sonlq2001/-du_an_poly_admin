export const LIST_BRANCH = [
  { value: 1, label: 'HÀ NỘI' },
  { value: 2, label: 'TÂY NGUYÊN' },
  { value: 3, label: 'CẦN THƠ' },
  { value: 4, label: 'ĐÀ NẴNG' },
  { value: 5, label: 'HỒ CHÍ MINH' },
];
