export const MAJORS_ENDPOINTS = {
  GET_MAJORS: '/majors',
  PUT_MAJORS: '/majors/update/:id',
  POST_MAJORS: '/majors/create',
  DELETE_MAJORS: '/majors/delete/:id',
};
