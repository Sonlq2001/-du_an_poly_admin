export const MAJORS_PATH = {
  LIST: '/majors',
};
