export const DATA_FAKE = [
	{ id: 1, name: "Thiết kế đồ họa", teacher: "Trần Hữu Thiện" },
	{ id: 2, name: "PHP 3", teacher: "Trần Hữu Thiện" },
	{ id: 3, name: "Thiết kế đồ họa", teacher: "Trần Hữu Thiện" },
	{ id: 4, name: "JS nâng cao", teacher: "Trần Hữu Thiện" },
	{ id: 5, name: "Kĩ năng học tập", teacher: "Trần Hữu Thiện" },
	{ id: 6, name: "Nodejs", teacher: "Trần Hữu Thiện" },
	{ id: 7, name: "Typescript", teacher: "Trần Hữu Thiện" },
	{ id: 8, name: "Thiết kế đồ họa", teacher: "Trần Hữu Thiện" },
];
