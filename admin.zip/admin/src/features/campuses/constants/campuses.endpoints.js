export const CAMPUSES_ENDPOINTS = {
  GET_CAMPUSES: '/campuses',
};
