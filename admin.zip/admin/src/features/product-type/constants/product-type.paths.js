export const PRODUCT_TYPE_PATH = {
  LIST: '/product-type',
};
