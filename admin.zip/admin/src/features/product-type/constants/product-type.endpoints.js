export const PRODUCT_TYPE_ENDPOINTS = {
  GET_PRODUCT_TYPE: '/product_types',
  POST_PRODUCT_TYPE: '/product_types',
  PUT_PRODUCT_TYPE: '/product_types/:id',
  DELETE_PRODUCT_TYPE: '/product_types/:id',
};
