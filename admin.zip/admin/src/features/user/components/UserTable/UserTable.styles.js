import styled from 'styled-components';

export const GroupPagination = styled.div`
  display: flex;
  justify-content: flex-end;
  margin-top: 2rem;
`;
export const BoxActionTable = styled.div`
  display: flex;
  justify-content: flex-end;
`;
