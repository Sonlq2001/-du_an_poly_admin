export const DATA_FAKE = [
	{ id: 1, name: "son", email: "son@example.com", phone: "04345123", role: 1 },
	{ id: 2, name: "hai", email: "hai@example.com", phone: "03454345", role: 2 },
	{
		id: 3,
		name: "dat",
		email: "dat@example.com",
		phone: "0897697756",
		role: 2,
	},
	{
		id: 4,
		name: "vinh",
		email: "vinh@example.com",
		phone: "046367677",
		role: 3,
	},
	{
		id: 5,
		name: "dung",
		email: "dung@example.com",
		phone: "097534587",
		role: 1,
	},
];
