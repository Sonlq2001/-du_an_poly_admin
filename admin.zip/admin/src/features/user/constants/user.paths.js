export const USER_PATHS = {
  LIST: '/user',
  USER_PROFILE: '/user/:id',
};
