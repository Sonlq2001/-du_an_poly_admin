export const USER_ENDPOINTS = {
  GET_USERS: '/users',
  GET_USERS_DETAIL: '/users/:id',
  PUT_USER: '/users/:id',
  POST_USER: '/users/create',
};
