import styled from "styled-components";

export const BoxChartMain = styled.div`
	background-color: var(--white-color);
	margin-top: 2rem;
	padding: 1.5rem;
	border-radius: 5px;
`;
