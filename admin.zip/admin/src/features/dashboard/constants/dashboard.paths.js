export const DASHBOARD_PATH = {
  LIST: '/',
};
