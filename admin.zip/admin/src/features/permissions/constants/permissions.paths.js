export const PERMISSIONS_PATH = {
  LIST: '/permissions',
};
