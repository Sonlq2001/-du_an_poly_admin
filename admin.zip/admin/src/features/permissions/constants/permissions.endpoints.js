export const  PERMISSIONS_ENDPOINT = {
  GET_PERMISSIONS: '/permissions',
  POST_PERMISSIONS: '/permissions',
  PUT_PERMISSIONS: '/permissions/:id',
  DELETE_PERMISSIONS: '/permissions/:id',
};
