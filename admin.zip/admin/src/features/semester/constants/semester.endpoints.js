export const SEMESTER_ENDPOINT = {
  GET_SEMESTERS: '/semesters',
  POST_SEMESTERS: '/semesters',
  PUT_SEMESTERS: '/semesters/:id',
  DELETE_SEMESTERS: '/semesters/:id',
};
