export const SEMESTER_PATH = {
  LIST: '/semester',
};
