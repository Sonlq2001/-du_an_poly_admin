export const AUTH_PATHS = {
  SIGN_IN: '/sign-in',
  AUTH_TOKEN: '/auth/google',
};
