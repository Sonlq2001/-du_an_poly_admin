export const AUTH_ENDPOINT = {
  POST_ACCESS_TOKEN: '/callback/google',
  POST_LOGOUT: '/logout',
  GET_CAMPUSES: '/campuses',
};
