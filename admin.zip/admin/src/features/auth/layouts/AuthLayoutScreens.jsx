import React, { memo } from 'react';

const AuthLayoutScreens = ({ children }) => {
  return <div>{children}</div>;
};

export default memo(AuthLayoutScreens);
