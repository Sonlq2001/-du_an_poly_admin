export const ROLE_ENDPOINTS = {
  GET_ROLES: '/roles',
  GET_ROLE_DETAIL: '/roles/:id',
  POST_ROLE: '/roles',
  PUT_ROLE: '/roles/:id',
  DELETE_ROLE: '/roles/:id',
};
