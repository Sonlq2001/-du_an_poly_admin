export const ROLE_PATHS = {
  LIST: '/role',
  ROLE_ACTION_ADD: '/role-action',
  ROLE_ACTION_EDIT: '/role-action/:id',
};
