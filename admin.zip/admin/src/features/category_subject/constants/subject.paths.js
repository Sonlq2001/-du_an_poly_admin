export const CATEGORY_SUBJECT_PATH = {
  LIST: '/categories_subjects',
  POST: '/categories_subjects',
  REMOVE: '/categories_subjects/:id',
  UPDATE: '/categories_subjects/:id',
};
export const CATEGORY_ROUTER_PATH = {
  LIST: '/category_subject',
};
