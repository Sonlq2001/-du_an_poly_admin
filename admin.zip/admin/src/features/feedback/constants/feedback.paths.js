export const FEEDBACK_PATH = {
  LIST: '/feedback',
};
