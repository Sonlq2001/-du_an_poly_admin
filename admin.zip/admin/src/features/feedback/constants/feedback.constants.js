export const DATA_FAKE = [
  {
    id: 1,
    user: 'Le quang son',
    product: 'Sản phẩm thiết kế đồ gia dụng',
    time: '10/10/2021',
    content: 'Sản phẩm đẹp quá',
  },
  {
    id: 2,
    user: 'Le quang son',
    product: 'Sản phẩm thiết kế đồ gia dụng',
    time: '10/10/2021',
    content: 'Sản phẩm đẹp quá',
  },
  {
    id: 3,
    user: 'Le quang son',
    product: 'Sản phẩm thiết kế đồ gia dụng',
    time: '10/10/2021',
    content: 'Sản phẩm đẹp quá',
  },
];
